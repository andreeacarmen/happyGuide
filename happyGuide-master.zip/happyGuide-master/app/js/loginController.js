app.controller('loginController', function($scope) {
    $scope.username = null;
    $scope.password = null;

    //TODO login logic
});
