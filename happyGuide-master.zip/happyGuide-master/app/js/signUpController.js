app.controller('signUpController', function($scope) {
    $scope.name = null;
    $scope.email = null;
    $scope.city = null;
    $scope.user = null;
    $scope.password = null;
    $scope.description = null;
    $scope.price = null;
});
