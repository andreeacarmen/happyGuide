package hg;

/**
 * Created by Andreea on 26.11.2016.
 */
public class UserCreate {

    private String username;

    public UserCreate(String username) {
        this.username = username;
    }

}
